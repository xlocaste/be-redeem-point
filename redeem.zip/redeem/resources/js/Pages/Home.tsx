const Home = () => {
    return (
        <main className="container mx-auto">
            <div className="flex justify-center items-center">
                <h1 className="font-bold text-2xl">Home Page</h1>
            </div>
        </main>
    );
};

export default Home;
